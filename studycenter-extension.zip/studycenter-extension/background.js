// StudyCenter Notifier — Background Service Worker
// Fires on every Chrome startup / Chromebook login

const STUDYCENTER_URL = 'https://geekbench2026.github.io/StudyCenter/StudyCenter.html';
const STORAGE_KEY = 'sc_v5';

// ── Fires on every Chromebook login / Chrome startup ──────────────────
chrome.runtime.onStartup.addListener(function() {
  fireStudyBriefing();
});

// ── Also fires when the extension is first installed ──────────────────
chrome.runtime.onInstalled.addListener(function() {
  fireStudyBriefing();
});

// ── Main function ─────────────────────────────────────────────────────
function fireStudyBriefing() {
  // Try to get data from chrome.storage (synced from the page)
  chrome.storage.local.get(STORAGE_KEY, function(result) {
    if (result && result[STORAGE_KEY]) {
      buildAndSendNotifs(result[STORAGE_KEY]);
    } else {
      // Fallback: fetch the page and extract localStorage data via a content script workaround
      // We'll send a generic notification pointing them to open the app
      sendNotif(
        'studycenter-open',
        '📚 StudyCenter — Good morning!',
        'Open the app to review your assignments and tests.'
      );
    }
  });
}

// ── Build notifications from saved data ──────────────────────────────
function buildAndSendNotifs(data) {
  var assignments = data.assignments || [];
  var tests = data.tests || [];
  var today = new Date();
  today.setHours(0, 0, 0, 0);

  function daysUntil(dateStr) {
    var d = new Date(dateStr + 'T00:00:00');
    d.setHours(0, 0, 0, 0);
    return Math.round((d - today) / 86400000);
  }

  var pending = assignments.filter(function(a) { return !a.done; });
  var overdue  = pending.filter(function(a) { return daysUntil(a.due) < 0; });
  var dueToday = pending.filter(function(a) { return daysUntil(a.due) === 0; });
  var dueTomorrow = pending.filter(function(a) { return daysUntil(a.due) === 1; });
  var dueSoon  = pending.filter(function(a) { var n = daysUntil(a.due); return n >= 2 && n <= 3; });
  var urgentTests = tests.filter(function(t) { var n = daysUntil(t.date); return n >= 0 && n <= 3; });

  var notifs = [];

  if (overdue.length === 1)
    notifs.push(['studycenter-overdue', '⚠️ Overdue Assignment', overdue[0].title + ' is past due!']);
  else if (overdue.length > 1)
    notifs.push(['studycenter-overdue', '⚠️ ' + overdue.length + ' Overdue Assignments', overdue.map(function(a){return a.title;}).join(', ')]);

  if (dueToday.length === 1)
    notifs.push(['studycenter-today', '📅 Due Today', dueToday[0].title + ' is due today!']);
  else if (dueToday.length > 1)
    notifs.push(['studycenter-today', '📅 ' + dueToday.length + ' Things Due Today', dueToday.map(function(a){return a.title;}).join(', ')]);

  if (dueTomorrow.length === 1)
    notifs.push(['studycenter-tomorrow', '🔔 Due Tomorrow', dueTomorrow[0].title + ' is due tomorrow.']);
  else if (dueTomorrow.length > 1)
    notifs.push(['studycenter-tomorrow', '🔔 ' + dueTomorrow.length + ' Things Due Tomorrow', dueTomorrow.map(function(a){return a.title;}).join(', ')]);

  if (dueSoon.length)
    notifs.push(['studycenter-soon', '📚 Coming Up Soon', dueSoon.map(function(a){return a.title + ' (in ' + daysUntil(a.due) + 'd)';}).join(', ')]);

  urgentTests.forEach(function(t, i) {
    var n = daysUntil(t.date);
    var when = n === 0 ? 'TODAY' : n === 1 ? 'tomorrow' : 'in ' + n + ' days';
    notifs.push(['studycenter-test-' + i, '📝 ' + t.type + ' ' + when + '!', t.title + ' (' + t.cls + ') is ' + when + '.']);
  });

  if (!notifs.length) {
    notifs.push(['studycenter-clear', '✅ All clear! — StudyCenter', 'Nothing urgent due in the next 3 days. Keep it up!']);
  }

  // Stagger notifications so they don't all fire at once
  notifs.forEach(function(n, i) {
    setTimeout(function() {
      sendNotif(n[0], n[1], n[2]);
    }, i * 900);
  });
}

// ── Send a single notification ────────────────────────────────────────
function sendNotif(id, title, message) {
  chrome.notifications.create(id, {
    type: 'basic',
    iconUrl: 'icon.png',
    title: title,
    message: message,
    priority: 2
  });
}

// ── Notification click → open StudyCenter ────────────────────────────
chrome.notifications.onClicked.addListener(function(notifId) {
  if (notifId.startsWith('studycenter')) {
    chrome.tabs.create({ url: STUDYCENTER_URL });
  }
});
